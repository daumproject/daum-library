import java.io.*;
import java.math.BigInteger;
import java.security.*;

import javax.crypto.BadPaddingException;

import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

/**
 * Created with IntelliJ IDEA.
 * User: jed
 * Date: 08/01/13
 * Time: 08:54
 * To change this template use File | Settings | File Templates.
 */
public class Tester {

    public static void saveToFile(String fileName,  BigInteger mod, BigInteger exp) throws IOException {
        ObjectOutputStream oout = new ObjectOutputStream( new BufferedOutputStream(new FileOutputStream(fileName)));
        try {
            oout.writeObject(mod);
            oout.writeObject(exp);
        } catch (Exception e) {
            throw new IOException("Unexpected error", e);
        } finally {
            oout.close();
        }
    }


    public static void main(String argv[]) throws NoSuchPaddingException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, IOException, SignatureException, InvalidKeySpecException {


        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.genKeyPair();
        Key publicKey = kp.getPublic();
        Key privateKey = kp.getPrivate();


        KeyFactory fact = KeyFactory.getInstance("RSA");
        RSAPublicKeySpec pub = fact.getKeySpec(kp.getPublic(),RSAPublicKeySpec.class);
        RSAPrivateKeySpec priv = fact.getKeySpec(kp.getPrivate(),RSAPrivateKeySpec.class);

       /* */
        System.out.println("<-------------- Private -------------- >");
        System.out.println(privateKey);
        System.out.println("<-------------- Private -------------- >");

        System.out.println("<-------------- Public -------------- >");
        System.out.println(publicKey);
        System.out.println("<-------------- Public -------------- >");
      // saveToFile("/tmp/pub.key", pub.getModulus(), pub.getPublicExponent());



       /*<----------------------- test SIGN--------------------------------> */
        byte[] data = "model kevoeoeoeo".getBytes("UTF8");

        Signature sig = Signature.getInstance("SHA1withRSA");
        sig.initSign(kp.getPrivate());
        sig.update(data);
        byte[] signatureBytes = sig.sign();
       // System.out.println("Singature:" + new BASE64Encoder().encode(signatureBytes));

        sig.initVerify(kp.getPublic());
        sig.update(data);

        System.out.println(sig.verify(signatureBytes));
           /*<----------------------- test SIGN  --------------------------------> */


      /*<----------------------- test ENCRYPT_MODE  --------------------------------> */
        Cipher cipher = Cipher.getInstance("RSA");

        cipher.init(Cipher.ENCRYPT_MODE, kp.getPublic());

        byte[] cipherText = cipher.doFinal(data);
        System.out.println("cipher: " + new String(cipherText));

         /*<----------------------- test DECRYPT_MODE  --------------------------------> */
        cipher.init(Cipher.DECRYPT_MODE, kp.getPrivate());
        byte[] plainText = cipher.doFinal(cipherText);
        System.out.println("plain : " + new String(plainText));



    }
}
