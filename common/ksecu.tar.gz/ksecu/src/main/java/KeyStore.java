/**
 * Created with IntelliJ IDEA.
 * User: jed
 * Date: 09/01/13
 * Time: 11:02
 * To change this template use File | Settings | File Templates.
 */

///todo store
public class KeyStore
{

}
